// Package log contains a transparent interface for logging which interacts with the system event queue.
package log
