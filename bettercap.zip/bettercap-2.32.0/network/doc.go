// Package network contains network specific code ... lol.
package network
